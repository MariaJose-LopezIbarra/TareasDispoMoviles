package com.example.ejercicio1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import com.example.ejercicio1.ui.theme.EJERCICIO1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EJERCICIO1Theme {
                // Llamamos a la tarea1 (calculadora de impuestos)
                tarea1(
                    numero = remember { mutableStateOf("") },
                    numeroEntered = remember { mutableStateOf(false) }
                )
            }
        }
    }
}

@Composable
fun tarea1(
    numero: MutableState<String>,
    numeroEntered: MutableState<Boolean>,
    modifier: Modifier = Modifier
) {
    var iva by remember { mutableStateOf(0.0) }
    var subtotal by remember { mutableStateOf(0.0) }
    var retencioniva by remember { mutableStateOf(0.0) }
    var retencionisr by remember { mutableStateOf(0.0) }
    var total by remember { mutableStateOf(0.0) }

    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
    ) {
        Text("Impuestos", fontSize = 25.sp, modifier = Modifier.padding(bottom = 24.dp))
        Text("Importe:", fontSize = 10.sp)
        TextField(
            value = numero.value,
            modifier = Modifier.fillMaxWidth(),
            onValueChange = { newValue ->
                if (newValue.all { it.isDigit() || it == '.' }) {
                    numero.value = newValue
                }
            },
            placeholder = { Text("Cantidad") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Text("IVA (16%) = $iva", modifier = Modifier.padding(top = 24.dp))
        Button(
            modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth(),
            onClick = {
                val num = numero.value.toDoubleOrNull() ?: 0.0
                iva = num * 0.16
                subtotal = num + iva
                retencioniva = iva * 0.10666
                retencionisr = num * 0.1
                total = num + iva - retencioniva - retencionisr
                numeroEntered.value = true
            }
        ) {
            Text("CALCULAR")
        }
        Text("Sub total = $subtotal", modifier = Modifier.padding(bottom = 16.dp))
        Text("Retención IVA = $retencioniva", modifier = Modifier.padding(bottom = 16.dp))
        Text("Retención ISR = $retencionisr", modifier = Modifier.padding(bottom = 16.dp))
        Text("Total = $total", modifier = Modifier.padding(bottom = 24.dp))
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    EJERCICIO1Theme {
        tarea1(
            numero = remember { mutableStateOf("") },
            numeroEntered = remember { mutableStateOf(false) }
        )
    }
}
