package com.example.ejercicio2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import com.example.ejercicio2.ui.theme.EJERCICIO2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EJERCICIO2Theme {
                tarea2(
                    Continue = { /* Lógica para continuar */ },
                    name = "Some Name"
                )
            }
        }
    }
}

@Composable
fun tarea2(Continue: () -> Unit, name: String, modifier: Modifier = Modifier) {
    val red = remember { mutableStateOf(true) }
    val green = remember { mutableStateOf(true) }
    val blue = remember { mutableStateOf(true) }

    ConstraintLayout(
        modifier = Modifier.fillMaxSize()
    ) {
        val (cbRojo, cbVerde, cbAzul, boxRojo, boxVerde, boxAzul, button) = createRefs()

        CBWL(label = "Rojo", state = red, modifier = Modifier.constrainAs(cbRojo) {
            top.linkTo(cbVerde.top)
            start.linkTo(cbVerde.end, margin = 32.dp)
        })

        CBWL(label = "Verde", state = green, modifier = Modifier.constrainAs(cbVerde) {
            top.linkTo(cbAzul.bottom, margin = 30.dp)
            start.linkTo(parent.start, margin = 140.dp)
        })

        CBWL(label = "Azul", state = blue, modifier = Modifier.constrainAs(cbAzul) {
            top.linkTo(parent.top, margin = 90.dp)
            start.linkTo(parent.start, margin = 16.dp)
        })

        if (red.value) {
            Box(
                modifier = Modifier
                    .background(Color.Red)
                    .constrainAs(boxRojo) {
                        bottom.linkTo(cbRojo.top, margin = 30.dp)
                        start.linkTo(cbRojo.start)
                        end.linkTo(cbRojo.end)
                        width = Dimension.value(100.dp)
                        height = Dimension.value(100.dp)
                    }
            )
        }

        if (green.value) {
            Box(
                modifier = Modifier
                    .background(Color.Green)
                    .constrainAs(boxVerde) {
                        top.linkTo(cbVerde.bottom, margin = 30.dp)
                        start.linkTo(cbVerde.start)
                        end.linkTo(cbVerde.end)
                        width = Dimension.value(100.dp)
                        height = Dimension.value(100.dp)
                    }
            )
        }

        if (blue.value) {
            Box(
                modifier = Modifier
                    .background(Color.Blue)
                    .constrainAs(boxAzul) {
                        top.linkTo(cbVerde.top, margin = -20.dp)
                        start.linkTo(parent.start, margin = 6.dp)
                        width = Dimension.value(100.dp)
                        height = Dimension.value(100.dp)
                    }
            )
        }

    }
}

@Composable
fun CBWL(label: String, state: MutableState<Boolean>, modifier: Modifier = Modifier) {
    ConstraintLayout(modifier = modifier.clickable {
        state.value = !state.value
    }) {
        val (checkbox, text) = createRefs()
        Checkbox(
            checked = state.value,
            onCheckedChange = {
                state.value = it
            },
            modifier = Modifier.constrainAs(checkbox) {}
        )
        Text(
            text = label,
            modifier = Modifier.constrainAs(text) {
                start.linkTo(checkbox.end, margin = 16.dp)
                top.linkTo(checkbox.top)
                bottom.linkTo(checkbox.bottom)
            }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun Preview() {
    EJERCICIO2Theme {
        tarea2(
            Continue = { /* Lógica para continuar */ },
            name = "Some Name"
        )
    }
}
